package live.Abhinav.iotapp.app;

/** Created by Abhinav on 7/5/2015. */
public class Endpoints {
    public static String URL_LIST="http://smartshelves.pe.hu/productlist.json";
    public static String URL_OFFERS="http://smartshelves.pe.hu/offers.php";
}
