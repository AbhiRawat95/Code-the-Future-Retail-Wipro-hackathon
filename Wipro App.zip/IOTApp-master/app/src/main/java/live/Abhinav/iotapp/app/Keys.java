package live.Abhinav.iotapp.app;

/**
 * Created by Abhinav on 7/4/2015.
 */
public class Keys {
    public static String KEY_SNO="barcode";
    public static String KEY_PNAME="name";

}
